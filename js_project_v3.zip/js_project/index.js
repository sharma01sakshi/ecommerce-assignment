const productsDiv = document.querySelector("#products");
(async () => {
  try {
    const response = await fetch("https://dummyjson.com/products");
    const data = await response.json();
    const products = data.products;
    products.forEach((product) => {
      productsDiv.innerHTML += `
<div class="bg-white rounded-2xl shadow-md hover:shadow-xl transition duration-300 overflow-hidden">

    <img
        src="${product.thumbnail}"
        alt="${product.title}"
        class="w-full h-52 object-cover"
    >

    <div class="p-5">

        <h2 class="text-xl font-bold text-gray-800">
            ${product.title}
        </h2>

        <p class="text-gray-500 mt-2 text-sm">
            ${product.description}
        </p>

        <h3 class="text-amber-600 text-2xl font-bold mt-4">
            $${product.price}
        </h3>

        <div class="flex justify-between mt-5">

            <a
                href="product.html?id=${product.id}"
                class="bg-rose-600 text-white px-4 py-2 rounded-lg hover:bg-rose-700 transition"
            >
                Details
            </a>

            <button
                onclick="addToCart(${product.id})"
                class="bg-amber-500 text-white px-4 py-2 rounded-lg hover:bg-amber-600 transition"
            >
                Add
            </button>

        </div>

    </div>
</div>
`;
});
  } catch {}
})();
function addToCart(id) {
  let cart = JSON.parse(localStorage.getItem("cart"));
  const product = cart.find((item) => item.id === id);
  if (!product) {
    cart.push({ id: id, quantity: 1 });
    localStorage.setItem("cart", JSON.stringify(cart));
  } else {
    product.quantity++;
    localStorage.setItem("cart", JSON.stringify(cart));
  }
}
