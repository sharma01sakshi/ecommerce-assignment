const productId = new URLSearchParams(window.location.search).get("id");
console.log(productId);
const productDiv = document.querySelector("#product");
(async () => {
  try {
    const response = await fetch(`https://dummyjson.com/products/${productId}`);
    const product = await response.json();
    console.log(product);
    productDiv.innerHTML = `
<div class="bg-white rounded-2xl shadow-lg p-8">

<div class="flex flex-col lg:flex-row gap-10">

<div class="lg:w-2/5">
<img
src="${product.thumbnail}"
class="rounded-xl w-full"
>
</div>

<div class="lg:w-3/5">

<h1 class="text-4xl font-bold text-gray-800">
${product.title}
</h1>

<p class="text-amber-600 text-3xl font-bold mt-5">
$${product.price}
</p>

<p class="text-gray-600 mt-6 leading-8">
${product.description}
</p>

<button
onclick="addToCart(${product.id})"
class="mt-8 bg-rose-600 text-white px-8 py-3 rounded-lg hover:bg-rose-700 transition"
>
Add to Cart
</button>

</div>

</div>

</div>
`;
  } catch {}
})();

function addToCart(id) {
  let cart = JSON.parse(localStorage.getItem("cart"));
  const product = cart.find((item) => item.id === id);
  if (!product) {
    cart.push({ id: id, quantity: 1 });
    localStorage.setItem("cart", JSON.stringify(cart));
  } else {
    product.quantity++;
    localStorage.setItem("cart", JSON.stringify(cart));
  }
}
