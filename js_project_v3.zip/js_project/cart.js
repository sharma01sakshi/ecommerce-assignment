let cart = JSON.parse(localStorage.getItem("cart"));
let totalAmountEl = document.querySelector(".total");
let totalAmount = 0;
const cartDiv = document.querySelector("#cart");
(async () => {
  try {
    const response = await fetch(`https://dummyjson.com/products`);
    const data = await response.json();
    const products = data.products;
    cart.forEach((element) => {
      const product = products.find((item) => item.id === element.id);
      cartDiv.innerHTML += `
<div class="bg-white rounded-2xl shadow-md hover:shadow-xl transition p-5">

<img
src="${product.thumbnail}"
class="w-full h-52 object-cover rounded-xl"
>

<h2 class="text-xl font-bold text-gray-800 mt-4">
${product.title}
</h2>

<p class="text-amber-600 text-2xl font-bold mt-2">
$${product.price}
</p>

<div class="mt-4 text-gray-600 space-y-2">

<p>
<span class="font-semibold">Quantity:</span>
${element.quantity}
</p>

<p>
<span class="font-semibold">Subtotal:</span>
<span class="text-amber-600 font-bold">
$${(product.price * element.quantity).toFixed(2)}
</span>
</p>

</div>

</div>
`;
      totalAmount += product.price * element.quantity;
    });
    totalAmountEl.innerHTML = `Total Amount: $${totalAmount.toFixed(2)}`;
  } catch {}
})();
