let cart = JSON.parse(localStorage.getItem("cart"));
let totalAmountEl = document.querySelector(".total");
let totalAmount = 0;
const cartDiv = document.querySelector("#cart");
(async () => {
  try {
    const response = await fetch(`https://dummyjson.com/products`);
    const data = await response.json();
    const products = data.products;
    cart.forEach((element) => {
      const product = products.find((item) => item.id === element.id);
      cartDiv.innerHTML += `
<div class="bg-white rounded-lg shadow-md p-4">
    <img
        src="${product.thumbnail}"
        alt="${product.title}"
        class="w-full h-48 object-fit rounded"
    >

    <div class="mt-4">
        <h2 class="text-lg font-semibold text-gray-800">
            ${product.title}
        </h2>

        <p class="text-indigo-600 font-bold text-xl mt-2">
            $${product.price}
        </p>

        <div class="mt-3 space-y-1 text-gray-600">
            <p><span class="font-medium">Quantity:</span> ${element.quantity}</p>
            <p>
                <span class="font-medium">Subtotal:</span>
                $${(product.price * element.quantity).toFixed(2)}
            </p>
        </div>
    </div>
</div>
`;
      totalAmount += product.price * element.quantity;
    });
    totalAmountEl.innerHTML = `Total Amount: $${totalAmount.toFixed(2)}`;
  } catch {}
})();
