const productsDiv = document.querySelector("#products");
(async () => {
  try {
    const response = await fetch("https://dummyjson.com/products");
    const data = await response.json();
    const products = data.products;
    products.forEach((product) => {
      productsDiv.innerHTML += `
        <div class="bg-white rounded-xl shadow-md p-5 hover:shadow-xl transition duration-300">
            <img
                src="${product.thumbnail}"
                alt="${product.title}"
                class="w-full h-48 object-cover rounded-lg"
            >
            <div class="mt-4">
                <h2 class="text-xl font-semibold text-gray-800">${product.title}</h2>
                <p class="text-gray-500 text-sm mt-2">${product.description}</p>
                <h3 class="text-indigo-700 text-lg font-bold mt-3">$${product.price}</h3>
                <div class="flex justify-between items-center mt-4">
                    <a
                        href="product.html?id=${product.id}"
                        class="bg-indigo-600 text-white px-4 py-2 rounded-md text-sm hover:bg-indigo-700 transition"
                    >
                        Details
                    </a>

                    <button
                        class="bg-orange-500 text-white px-4 py-2 rounded-md text-sm hover:bg-orange-600 transition"
                        onclick="addToCart(${product.id})"
                    >
                        Add
                    </button>
                </div>
            </div>
        </div>
        `;
    });
  } catch {}
})();
function addToCart(id) {
  let cart = JSON.parse(localStorage.getItem("cart"));
  const product = cart.find((item) => item.id === id);
  if (!product) {
    cart.push({ id: id, quantity: 1 });
    localStorage.setItem("cart", JSON.stringify(cart));
  } else {
    product.quantity++;
    localStorage.setItem("cart", JSON.stringify(cart));
  }
}
